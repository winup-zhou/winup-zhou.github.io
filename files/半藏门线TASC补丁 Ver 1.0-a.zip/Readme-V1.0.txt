半藏门线TASC补丁  Ver 1.0
本补丁适用的插件名称：bve-autopilot
此补丁修改的内容为本人原创

#########更新日志##########
beta1
公开

beta2
修正附带车辆的显示问题

Ver 1.0
剔除车辆数据改为单独发布

-------------------------------
作者QQ：3166832341
作者BiliBili ID：Win_Update
E-mail：3166832341@qq.com
未经授权，禁止盗用，违者必究！
制作相关视频是允许的，转载请标明原作者

车辆侧autopilot请自行导入
因没有编写弯道限速信标，请在车辆侧autopilot的配置文件autopilot.ini中加入下列语句：
[ato]
atcprebrake = true

###########
2020/8/22 13:13 Windows_Update